import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editor',
  templateUrl: './editor.component.html',
  styleUrls: ['./editor.component.scss']
})
export class EditorComponent implements OnInit {

  toolbar: any = [
    {
      icon: 'assets/icons/toolbar/theme.svg',
      text: 'Theme',
      link: ['/editor/theme']
    },
    {
      icon: 'assets/icons/toolbar/text.svg',
      text: 'Text',
      link: ['/editor/text']
    },
    {
      icon: 'assets/icons/toolbar/media.svg',
      text: 'Media',
      link: ['/editor/media']
    },
    {
      icon: 'assets/icons/toolbar/music.svg',
      text: 'Music',
      link: ['/editor/music']
    },
    {
      icon: 'assets/icons/toolbar/format.svg',
      text: 'Format',
      link: ['/editor/format']
    },
  ];

  constructor() { }

  ngOnInit() {
  }

}
