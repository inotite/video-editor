import { Component, OnInit, HostBinding, ViewChild, Input } from '@angular/core';

@Component({
  selector: 'app-canvas-text',
  templateUrl: './canvas-text.component.html',
  styleUrls: ['./canvas-text.component.scss']
})
export class CanvasTextComponent implements OnInit {

  showBox: boolean;
  fontSize: Number;

  @HostBinding('style.align-items')
  alignItems = 'flex-start';

  @HostBinding('style.justify-content')
  justifyContent = 'flex-start';

  @ViewChild('subtitle') subtitle;

  @Input()
  item: any;

  constructor() {
    this.showBox = false;
    this.fontSize = 32;
  }

  onFontSizeChange(fontSize: String) {
    console.log(fontSize);
    switch(fontSize) {
      case "s":
        this.fontSize = 16;
        break;
      case "m":
        this.fontSize = 24;
        break;
      case "l":
      default:
        this.fontSize = 32;
        break;
    }
  }

  onHighlightText(event) {
    // console.log(this.subtitle.nativeElement.);
    var sel = window.getSelection().getRangeAt(0);

    console.log(sel);

    document.execCommand('foreColor', true, '#EF6FA4');
    
  }

  onAlignmentChange(alignment: Number) {
    console.log(alignment);
    switch(alignment) {
      case 1:
        this.justifyContent = "flex-start";
        this.alignItems = "flex-start";
        break;
      case 2:
        this.justifyContent = "flex-start";
        this.alignItems = "center";
        break;
      case 3:
        this.justifyContent = "flex-start";
        this.alignItems = "flex-end";
        break;
      case 4:
        this.justifyContent = "center";
        this.alignItems = "flex-start";
        break;
      case 5:
        this.justifyContent = "center";
        this.alignItems = "center";
        break;
      case 6:
        this.justifyContent = "center";
        this.alignItems = "flex-end";
        break;
      case 7:
        this.justifyContent = "flex-end";
        this.alignItems = "flex-start";
        break;
      case 8:
        this.justifyContent = "flex-end";
        this.alignItems = "center";
        break;
      case 9:
        this.justifyContent = "flex-end";
        this.alignItems = "flex-end";
        break;
    }
  }

  ngOnInit() {
    this.onFontSizeChange(this.item.size);
    this.onAlignmentChange(this.item.position);
  }

}
