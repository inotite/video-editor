import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-templates',
  templateUrl: './templates.component.html',
  styleUrls: ['./templates.component.scss']
})
export class TemplatesComponent implements OnInit {

  templates: any = [
    {
      link: '/',
      src: 'assets/images/templates/rating@2x.png'
    },
    {
      link: '/',
      src: 'assets/images/templates/logo@2x.png'
    },
    {
      link: '/',
      src: 'assets/images/templates/feedback@2x.png'
    },
    {
      link: '/',
      src: 'assets/images/templates/sizes@2x.png'
    },
    {
      link: '/',
      src: 'assets/images/templates/price@2x.png'
    }
  ];

  constructor() { }

  ngOnInit() {
  }

}
