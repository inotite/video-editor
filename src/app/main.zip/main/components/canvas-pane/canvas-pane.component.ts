import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-canvas-pane',
  templateUrl: './canvas-pane.component.html',
  styleUrls: ['./canvas-pane.component.scss']
})
export class CanvasPaneComponent implements OnInit {

  @Output() addSceneEvent = new EventEmitter<any>();
  @Output() duplicateSceneEvent = new EventEmitter<any>();
  @Output() removeSceneEvent = new EventEmitter<any>();

  @Input()
  item: any;

  constructor() { }

  ngOnInit() {
    var canvasPane: any = document.getElementsByTagName('app-canvas-pane');
    for (var i = 1 ; i < canvasPane.length ; i++) {
      canvasPane[i].style.width = canvasPane[0].style.width;
    }
    
    var canvasDraw: any = document.getElementsByClassName('canvas-draw');
    for (var i = 1 ; i < canvasDraw.length ; i++) {
      canvasDraw[i].style.paddingTop = canvasDraw[0].style.paddingTop;
    }
  }

  playStop() {
    
  }

  duplicateSlide() {
    this.duplicateSceneEvent.emit(this.item);
  }

  deleteSlide() {
    this.removeSceneEvent.emit(this.item);
  }

  advancedSlide() {

  }

  onItemDrop(e: any) {
    console.log(e.dragData);
    this.item.image = e.dragData;
  }

  onAddScene(event: any) {
    this.addSceneEvent.emit(this.item);
  }

  onAddSubScene(event: any) {
    // this.addSub
  }

}
