import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-storyboard',
  templateUrl: './storyboard.component.html',
  styleUrls: ['./storyboard.component.scss']
})
export class StoryboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
