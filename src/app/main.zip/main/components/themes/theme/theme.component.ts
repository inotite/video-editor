import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-theme-slide',
  templateUrl: './theme.component.html',
  styleUrls: ['./theme.component.scss']
})
export class ThemeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
