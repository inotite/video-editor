import { Component, OnInit } from '@angular/core';
import { MediaItemService } from 'src/app/services/media-item.service';

@Component({
  selector: 'app-media-search',
  templateUrl: './media-search.component.html',
  styleUrls: ['./media-search.component.scss']
})
export class MediaSearchComponent implements OnInit {

  types: any = [
    {
      link: '/',
      text: 'Grass'
    },
    {
      link: '/',
      text: 'Shoes'
    },
    {
      link: '/',
      text: 'Summer'
    },
    {
      link: '/',
      text: 'Beach'
    },
    {
      link: '/',
      text: 'Flip flops'
    },
    {
      link: '/',
      text: 'Sandals'
    },
  ];

  items: any = [];

  constructor(private mediaItemService: MediaItemService) { }

  ngOnInit() {
    this.mediaItemService.getAll().subscribe(response => {
      this.items = response.photos;
    })
  }

}
