import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-media-used',
  templateUrl: './media-used.component.html',
  styleUrls: ['./media-used.component.scss']
})
export class MediaUsedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
