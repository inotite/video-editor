import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-music-library',
  templateUrl: './music-library.component.html',
  styleUrls: ['./music-library.component.scss']
})
export class MusicLibraryComponent implements OnInit {

  types: any = [
    {
      link: '/',
      text: 'Angry'
    },
    {
      link: '/',
      text: 'Bright'
    },
    {
      link: '/',
      text: 'Calm'
    },
    {
      link: '/',
      text: 'Dark'
    },
    {
      link: '/',
      text: 'Dramatic'
    },
    {
      link: '/',
      text: 'Funky'
    },
    {
      link: '/',
      text: 'Happy'
    },
    {
      link: '/',
      text: 'Inspirational'
    },
    {
      link: '/',
      text: 'Romantic'
    },
    {
      link: '/',
      text: 'Sad'
    },
  ];

  musics: any = [
    {
      name: "Music Track Name",
      type: 0
    },
    {
      name: "Music Track Name",
      type: 0
    },
    {
      name: "Music Track Name",
      type: 0
    },
    {
      name: "Music Track Name",
      type: 0
    },
    {
      name: "Music Track Name",
      type: 0
    },
    {
      name: "Music Track Name",
      type: 0
    },
    {
      name: "Music Track Name",
      type: 0
    },
  ];

  appliedMusics: any = [
    {
      name: "Music Track Name",
      type: 1
    },
    {
      name: "Music Track Name",
      type: 1
    },
    {
      name: "Music Track Name",
      type: 1
    }
  ];

  constructor() { }

  ngOnInit() {
  }

}
