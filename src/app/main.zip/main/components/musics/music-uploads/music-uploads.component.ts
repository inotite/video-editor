import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-music-uploads',
  templateUrl: './music-uploads.component.html',
  styleUrls: ['./music-uploads.component.scss']
})
export class MusicUploadsComponent implements OnInit {

  uploads: any = [
    {
      name: "user audio track 1.mp3",
      type: 2
    },
    {
      name: "user audio track 2.mp3",
      type: 2
    },
    {
      name: "user audio track 3.mp3",
      type: 2
    }
  ];

  constructor() { }

  ngOnInit() {
  }

}
