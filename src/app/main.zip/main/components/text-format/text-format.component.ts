import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { NgbDropdownConfig } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-text-format',
  templateUrl: './text-format.component.html',
  styleUrls: ['./text-format.component.scss']
})
export class TextFormatComponent implements OnInit {

  @Output() fontSizeEvent = new EventEmitter<String>();
  @Output() alignmentEvent = new EventEmitter<Number>();
  @Output() highlightEvent = new EventEmitter<void>();

  constructor(config: NgbDropdownConfig) { 
    // config.placement = 'top-left';
  }

  fontSizeChange(fontSize) {
    this.fontSizeEvent.emit(fontSize);
  }

  alignmentChange(alignment) {
    console.log(alignment);
    
    this.alignmentEvent.emit(parseInt(alignment));
  }

  highlightText(event) {
    this.highlightEvent.emit();
  }

  ngOnInit() {
  }

}
