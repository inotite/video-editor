import { Component, OnInit, ViewChild } from '@angular/core';

import { PerfectScrollbarConfigInterface, PerfectScrollbarComponent, PerfectScrollbarDirective } from 'ngx-perfect-scrollbar';
import { CurrentSlideService } from 'src/app/services/current-slide.service';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { CanvasEditorService } from 'src/app/services/canvas-editor.service';

@Component({
  selector: 'app-canvas-editor',
  templateUrl: './canvas-editor.component.html',
  styleUrls: ['./canvas-editor.component.scss']
})
export class CanvasEditorComponent implements OnInit {

  public config: PerfectScrollbarConfigInterface = {};

  currentSlides$ : Observable<any>;
  currentSlides: any[];

  @ViewChild(PerfectScrollbarComponent) componentRef?: PerfectScrollbarComponent;

  constructor(
    private currentSlideService: CurrentSlideService,
    private cnavasEditorService: CanvasEditorService) { }

  ngOnInit() {
    // this.currentSlides$ = this.currentSlideService.getAll();
    this.currentSlideService.getAll().subscribe(data => {
      this.currentSlides = data;
    })
  }

  public onScrollEvent(event: any): void {
    // console.log(event);
  }

  onAddScene(item) {
    var newItem = {
      id: this.currentSlides.length + 1,
      image: "assets/graphics/scene-placeholder.svg",
      text: {
          content: "New Sparka Scene",
          size: "m",
          position: 5,
          animation: "fadein"
      },
      duration: 6,
      position: this.currentSlides.length + 1,
      animation: "fadein"
    }
    this.currentSlides.push(newItem);
    this.cnavasEditorService.reCalc();
  }

  onDuplicateScene(item) {
    var newItem = item;
    newItem.id = this.currentSlides.length + 1;
    newItem.position = newItem.id;
    this.currentSlides.push(newItem);
    this.cnavasEditorService.reCalc();
  }

  onRemoveScene(item) {
    var index = this.currentSlides.indexOf(item);
    if (index !== -1) {
      this.currentSlides.splice(index, 1);
      this.cnavasEditorService.reCalc();
    }
  }

}
